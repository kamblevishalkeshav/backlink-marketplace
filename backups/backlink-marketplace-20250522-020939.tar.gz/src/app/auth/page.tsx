'use client';

export default function AuthPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Authentication</h1>
      <p className="mt-4">Please sign in to continue.</p>
    </div>
  );
} 