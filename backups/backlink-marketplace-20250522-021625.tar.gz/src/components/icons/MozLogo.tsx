import React from 'react';

interface MozLogoProps {
  width?: number;
  height?: number;
  className?: string;
}

const MozLogo: React.FC<MozLogoProps> = ({ width = 24, height = 24, className = '' }) => {
  return (
    <svg 
      width={width} 
      height={height} 
      className={className}
      viewBox="0 0 172.9 50" 
      xmlns="http://www.w3.org/2000/svg"
      style={{ minWidth: width }}
    >
      <g>
        <path 
          fill="#4DBDEB" 
          d="M147.9,33.3l25-27.1h-52.3c-1,0-1.8,0.8-1.9,1.8v5.7C114,5.6,104.1,0,92.7,0C79.2,0,67.9,7.8,64.6,18.5V6.2
          h-9.1c-2.2,0-4.1,1-5.5,2.5L32.3,28.1L14.6,8.7c-1.4-1.5-3.3-2.4-5.5-2.5H0v39.6h10.7c1,0,1.8-0.9,1.8-1.9V25l19.8,21.9L52.1,25
          v18.9c0,1,0.9,1.8,1.9,1.9h10.6V31.5C67.9,42.2,79.2,50,92.7,50c16.1,0,29.2-11.2,29.2-25c0-2.2-0.4-4.2-1-6.2h22.8l-25,27.1h52.3
          c1,0,1.8-0.8,1.9-1.8V33.3H147.9z M92.8,37.4c-7.8,0-14.2-5.6-14.2-12.4c0-6.9,6.4-12.4,14.2-12.4c7.9,0,14.2,5.6,14.2,12.4
          S100.7,37.4,92.8,37.4z"
        />
      </g>
    </svg>
  );
};

export default MozLogo; 