export interface Language {
  id: string;
  name: string;
  code: string;
  script?: string;
} 