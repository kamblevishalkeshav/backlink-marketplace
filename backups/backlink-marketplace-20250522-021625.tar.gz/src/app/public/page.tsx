'use client';

export default function PublicPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Public Content</h1>
      <p className="mt-4">This is public content accessible to all users.</p>
    </div>
  );
} 