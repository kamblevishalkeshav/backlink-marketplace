'use client';

export default function CategoriesPage() {
  return (
    <div className="space-y-2">
      <h1 className="text-3xl font-bold">Categories</h1>
      <p className="text-gray-500">Coming soon…</p>
    </div>
  );
} 