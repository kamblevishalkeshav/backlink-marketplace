'use client';

export default function PayoutsPage() {
  return (
    <div className="space-y-2">
      <h1 className="text-3xl font-bold">Payouts</h1>
      <p className="text-gray-500">Coming soon…</p>
    </div>
  );
} 