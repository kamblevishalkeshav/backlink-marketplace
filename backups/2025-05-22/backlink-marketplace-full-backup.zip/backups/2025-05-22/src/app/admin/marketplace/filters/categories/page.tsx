import CategoryTable from '@/components/admin/marketplace/CategoryTable';
export default function CategoriesPage() {
  return <CategoryTable />;
} 