'use client';

export default function ReviewQueuePage() {
  return (
    <div className="space-y-2">
      <h1 className="text-3xl font-bold">Review Queue</h1>
      <p className="text-gray-500">Coming soon…</p>
    </div>
  );
} 