import CountryTable from '@/components/admin/marketplace/CountryTable';
export default function CountriesPage() {
  return <CountryTable />;
} 