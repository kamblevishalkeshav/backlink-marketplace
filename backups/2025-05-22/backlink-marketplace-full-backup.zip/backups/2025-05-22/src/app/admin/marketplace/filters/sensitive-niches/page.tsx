import SensitiveNicheTable from '@/components/admin/marketplace/SensitiveNicheTable';
export default function SensitiveNichesPage() {
  return <SensitiveNicheTable />;
} 