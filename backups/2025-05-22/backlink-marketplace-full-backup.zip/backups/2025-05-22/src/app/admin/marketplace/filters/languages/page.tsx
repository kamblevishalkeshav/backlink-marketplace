import LanguageTable from '@/components/admin/marketplace/LanguageTable';
export default function LanguagesPage() {
  return <LanguageTable />;
} 