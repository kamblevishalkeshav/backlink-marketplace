'use client';

export default function PublisherPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Publisher Dashboard</h1>
      <p className="mt-4">Welcome to the publisher dashboard.</p>
    </div>
  );
} 